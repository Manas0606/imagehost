import 'package:jyotish/jyotish.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../models.dart';

class AstroService {
  final Jyotish _jyotish = Jyotish();
  bool _ready = false;

  static const _signs = [
    'Aries','Taurus','Gemini','Cancer','Leo','Virgo',
    'Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'
  ];

  Future<void> initialize() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    await _jyotish.initialize();
    _ready = true;
  }

  Future<AstroChartSnapshot> calculate(BirthProfile profile) async {
    await initialize();
    tz.Location zone;
    try {
      zone = tz.getLocation(profile.timezone);
    } catch (_) {
      zone = tz.UTC;
    }
    final localBirth = tz.TZDateTime(
      zone,
      profile.birthDate.year,
      profile.birthDate.month,
      profile.birthDate.day,
      profile.hour,
      profile.minute,
    );
    final instant = localBirth.toUtc();
    final geo = GeographicLocation(
      latitude: profile.latitude,
      longitude: profile.longitude,
      altitude: 0,
    );
    final chart = await _jyotish.calculateVedicChart(
      dateTime: instant,
      location: geo,
      houseSystem: 'W',
      flags: CalculationFlags.siderealLahiri(),
    );
    final panchanga = await _jyotish.calculatePanchanga(
      dateTime: instant,
      location: geo,
    );

    final planets = <PlanetSnapshot>[];
    const ordered = [
      Planet.sun, Planet.moon, Planet.mercury, Planet.venus,
      Planet.mars, Planet.jupiter, Planet.saturn,
    ];
    for (final planet in ordered) {
      final info = chart.getPlanet(planet);
      if (info == null) continue;
      planets.add(PlanetSnapshot(
        name: _planetName(planet),
        longitude: info.longitude,
        sign: info.zodiacSign,
        degree: info.position.positionInSign,
        nakshatra: info.nakshatra,
        pada: info.pada,
        house: info.house,
        retrograde: info.isRetrograde,
        navamsa: navamsaSign(info.longitude),
      ));
    }
    final rahu = chart.rahu;
    planets.add(PlanetSnapshot(
      name: 'Rahu',
      longitude: rahu.longitude,
      sign: rahu.zodiacSign,
      degree: rahu.position.positionInSign,
      nakshatra: rahu.nakshatra,
      pada: rahu.pada,
      house: rahu.house,
      retrograde: true,
      navamsa: navamsaSign(rahu.longitude),
    ));
    final ketu = chart.ketu;
    final ascIndex = (chart.ascendant / 30).floor() % 12;
    final ketuSignIndex = (ketu.longitude / 30).floor() % 12;
    planets.add(PlanetSnapshot(
      name: 'Ketu',
      longitude: ketu.longitude,
      sign: ketu.zodiacSign,
      degree: ketu.positionInSign,
      nakshatra: ketu.nakshatra,
      pada: ketu.nakshatraPada,
      house: ((ketuSignIndex - ascIndex + 12) % 12) + 1,
      retrograde: true,
      navamsa: navamsaSign(ketu.longitude),
    ));

    final moon = chart.getPlanet(Planet.moon)!;
    final dashaResult = DashaService().calculateVimshottariDasha(
      moonLongitude: moon.longitude,
      birthDateTime: instant,
      levels: 3,
    );
    final now = DateTime.now().toUtc();
    final currentMd = dashaResult.getMahadashaAt(now);
    final currentAd = dashaResult.getAndardashaAt(now);
    final currentPd = dashaResult.getPratyantardashaAt(now);
    final timeline = dashaResult.allMahadashas.map((d) => DashaRow(
      lord: d.lordDisplayName,
      startsAt: d.startDate,
      endsAt: d.endDate,
      active: d.isActiveAt(now),
    )).toList();

    return AstroChartSnapshot(
      profile: profile,
      ascendant: chart.ascendantSign,
      ascendantDegree: chart.ascendant % 30,
      moonSign: moon.zodiacSign,
      moonNakshatra: moon.nakshatra,
      moonPada: moon.pada,
      planets: planets,
      panchang: PanchangSnapshot(
        tithi: panchanga.tithi.name,
        paksha: panchanga.tithi.paksha.sanskrit,
        nakshatra: '${panchanga.nakshatra.name} • Pada ${panchanga.nakshatra.pada}',
        yoga: panchanga.yoga.name,
        karana: panchanga.karana.name,
        vara: panchanga.vara.name,
        sunrise: panchanga.sunrise,
        sunset: panchanga.sunset,
      ),
      dasha: DashaSnapshot(
        currentMahadasha: currentMd?.lordDisplayName ?? '—',
        currentAntardasha: currentAd?.lordDisplayName ?? '—',
        currentPratyantar: currentPd?.lordDisplayName ?? '—',
        timeline: timeline,
      ),
      calculatedAt: DateTime.now(),
    );
  }

  String navamsaSign(double longitude) {
    final lon = ((longitude % 360) + 360) % 360;
    final sign = (lon / 30).floor();
    final within = lon - sign * 30;
    final part = (within / (30 / 9)).floor().clamp(0, 8);
    final modality = sign % 3;
    final start = modality == 0 ? sign : modality == 1 ? (sign + 8) % 12 : (sign + 4) % 12;
    return _signs[(start + part) % 12];
  }

  String _planetName(Planet p) {
    final raw = p.displayName;
    return raw.isEmpty ? p.name : raw;
  }
}
