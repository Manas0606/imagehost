import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:lat_lng_to_timezone/lat_lng_to_timezone.dart' as tzmap;
import '../models.dart';

class PlaceService {
  static const _base = 'https://nominatim.openstreetmap.org/search';

  Future<List<PlaceSuggestion>> search(String query) async {
    final q = query.trim();
    if (q.length < 2) return const [];
    final uri = Uri.parse(_base).replace(queryParameters: {
      'q': q,
      'format': 'jsonv2',
      'limit': '8',
      'addressdetails': '1',
      'accept-language': 'en',
    });
    try {
      final response = await http.get(uri, headers: const {
        'User-Agent': 'AstroJeevan/2.0 (cross-platform astrology app)',
        'Accept': 'application/json',
      }).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) return const [];
      final data = jsonDecode(response.body) as List<dynamic>;
      return data.map((e) {
        final m = e as Map<String, dynamic>;
        final address = (m['address'] as Map<String, dynamic>?) ?? const {};
        return PlaceSuggestion(
          displayName: (m['display_name'] as String?) ?? q,
          latitude: double.tryParse('${m['lat']}') ?? 0,
          longitude: double.tryParse('${m['lon']}') ?? 0,
          countryCode: '${address['country_code'] ?? ''}'.toUpperCase(),
          state: address['state']?.toString(),
          district: (address['state_district'] ?? address['county'])?.toString(),
          village: (address['village'] ?? address['town'] ?? address['city'] ?? address['hamlet'])?.toString(),
        );
      }).where((p) => p.latitude.abs() <= 90 && p.longitude.abs() <= 180).toList();
    } catch (_) {
      return const [];
    }
  }

  String timezoneFor(double lat, double lng) {
    try {
      final zone = tzmap.latLngToTimezoneString(lat, lng);
      if (zone.trim().isNotEmpty) return zone;
    } catch (_) {}
    return 'UTC';
  }
}
