import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AuthResult {
  final bool ok;
  final String message;
  final String? displayName;
  final String? email;
  const AuthResult(this.ok, this.message, {this.displayName, this.email});
}

class AuthService {
  static const baseUrl = 'https://ep-orange-snow-a6j71rhq.neonauth.us-west-2.aws.neon.tech/neondb/auth';
  static const resetRedirect = 'https://manas0606.github.io/imagehost/reset.html';
  static const _prefName = 'astrojeevan_name';
  static const _prefEmail = 'astrojeevan_email';
  static const _prefGuest = 'astrojeevan_guest';

  Future<AuthResult> signUp({required String name, required String email, required String password}) async {
    if (name.trim().length < 2) return const AuthResult(false, 'Please enter your full name.');
    if (!email.contains('@')) return const AuthResult(false, 'Please enter a valid email.');
    if (password.length < 8) return const AuthResult(false, 'Password must be at least 8 characters.');
    return _post('/sign-up/email', {
      'name': name.trim(),
      'email': email.trim().toLowerCase(),
      'password': password,
    }, fallbackName: name.trim(), fallbackEmail: email.trim().toLowerCase());
  }

  Future<AuthResult> signIn({required String email, required String password}) async {
    if (!email.contains('@') || password.isEmpty) return const AuthResult(false, 'Enter email and password.');
    final result = await _post('/sign-in/email', {
      'email': email.trim().toLowerCase(),
      'password': password,
      'rememberMe': true,
    }, fallbackEmail: email.trim().toLowerCase());
    return result;
  }

  Future<AuthResult> requestPasswordReset(String email) async {
    if (!email.contains('@')) return const AuthResult(false, 'Please enter a valid email.');
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/request-password-reset'),
        headers: const {'content-type': 'application/json', 'accept': 'application/json'},
        body: jsonEncode({'email': email.trim().toLowerCase(), 'redirectTo': resetRedirect}),
      ).timeout(const Duration(seconds: 12));
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return const AuthResult(true, 'Password reset link requested. Please check your email.');
      }
      final body = _messageFrom(response.body);
      return AuthResult(false, body.isEmpty ? 'Unable to request password reset.' : body);
    } catch (_) {
      return const AuthResult(false, 'Network unavailable. Please try again when connected.');
    }
  }

  Future<AuthResult> _post(String path, Map<String, dynamic> payload, {String? fallbackName, String? fallbackEmail}) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl$path'),
        headers: const {'content-type': 'application/json', 'accept': 'application/json'},
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 12));
      if (response.statusCode >= 200 && response.statusCode < 300) {
        String? name = fallbackName;
        String? email = fallbackEmail;
        try {
          final body = jsonDecode(response.body);
          if (body is Map<String, dynamic>) {
            final user = body['user'];
            if (user is Map<String, dynamic>) {
              name = user['name']?.toString() ?? name;
              email = user['email']?.toString() ?? email;
            }
          }
        } catch (_) {}
        final prefs = await SharedPreferences.getInstance();
        if (name != null && name.isNotEmpty) await prefs.setString(_prefName, name);
        if (email != null && email.isNotEmpty) await prefs.setString(_prefEmail, email);
        await prefs.setBool(_prefGuest, false);
        return AuthResult(true, 'Success', displayName: name, email: email);
      }
      final msg = _messageFrom(response.body);
      return AuthResult(false, msg.isEmpty ? 'Authentication failed.' : msg);
    } catch (_) {
      return const AuthResult(false, 'Unable to connect to account service. You can continue as guest.');
    }
  }

  Future<void> continueAsGuest() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_prefGuest, true);
    if ((prefs.getString(_prefName) ?? '').isEmpty) await prefs.setString(_prefName, 'Guest');
  }

  Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefName);
    await prefs.remove(_prefEmail);
    await prefs.remove(_prefGuest);
  }

  Future<({bool hasSession, String name, String email, bool guest})> localSession() async {
    final prefs = await SharedPreferences.getInstance();
    final name = prefs.getString(_prefName) ?? '';
    final email = prefs.getString(_prefEmail) ?? '';
    final guest = prefs.getBool(_prefGuest) ?? false;
    return (hasSession: name.isNotEmpty || guest, name: name.isEmpty ? 'Guest' : name, email: email, guest: guest);
  }

  String _messageFrom(String body) {
    try {
      final decoded = jsonDecode(body);
      if (decoded is Map<String, dynamic>) {
        for (final key in ['message', 'error', 'detail']) {
          final value = decoded[key];
          if (value is String && value.isNotEmpty) return value;
          if (value is Map && value['message'] is String) return value['message'] as String;
        }
      }
    } catch (_) {}
    return '';
  }
}
